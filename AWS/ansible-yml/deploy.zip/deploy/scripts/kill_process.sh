#! /bin/bash
docker-compose -f /home/ubuntu/deploy/scripts/docker-compose.yml down || true
